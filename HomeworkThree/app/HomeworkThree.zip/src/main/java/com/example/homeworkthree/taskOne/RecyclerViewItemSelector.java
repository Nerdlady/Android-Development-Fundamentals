package com.example.homeworkthree.taskOne;


public interface RecyclerViewItemSelector {
    void onItemSelect(int positon);
}
